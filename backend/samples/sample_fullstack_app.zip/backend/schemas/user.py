from pydantic import BaseModel

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: str
    is_active: bool = True

class UserCreate(BaseModel):
    name: str
    email: str
