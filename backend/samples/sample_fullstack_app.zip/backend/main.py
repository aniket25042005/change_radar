from fastapi import FastAPI
from routes.users import router as users_router

app = FastAPI(title="Sample Store API")
app.include_router(users_router)
