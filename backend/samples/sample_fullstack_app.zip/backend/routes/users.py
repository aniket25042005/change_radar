from typing import List
from fastapi import APIRouter, HTTPException
from schemas.user import UserResponse, UserCreate

router = APIRouter(prefix="/users")

@router.get("", response_model=List[UserResponse])
def list_users() -> List[UserResponse]:
    return []

@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: int) -> UserResponse:
    return UserResponse(id=user_id, name="Alice", email="alice@example.com", role="admin")

@router.post("", response_model=UserResponse)
def create_user(payload: UserCreate) -> UserResponse:
    return UserResponse(id=1, name=payload.name, email=payload.email, role="user")
