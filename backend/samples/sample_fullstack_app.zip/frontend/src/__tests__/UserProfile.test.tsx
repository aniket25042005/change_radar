import { render, screen } from "@testing-library/react";
import { UserProfile } from "../components/UserProfile";
import { User } from "../types/user";

const mockUser: User = {
  id: 101,
  name: "Charlie",
  email: "charlie@example.com",
  role: "manager",
};

describe("UserProfile component", () => {
  it("renders user name and email", () => {
    render(<UserProfile user={mockUser} />);
    expect(screen.getByText("Charlie")).toBeDefined();
    expect(screen.getByText(/charlie@example.com/)).toBeDefined();
    expect(mockUser.email).toBe("charlie@example.com");
  });
});
