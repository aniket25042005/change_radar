import React from "react";
import { User } from "../types/user";
import { UserProfile } from "./UserProfile";

export const UserList: React.FC<{ users: User[] }> = ({ users }) => (
  <div className="user-grid">
    {users.map(u => <UserProfile key={u.id} user={u} />)}
  </div>
);
