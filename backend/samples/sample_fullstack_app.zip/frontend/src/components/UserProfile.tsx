import React from "react";
import { User } from "../types/user";

interface UserProfileProps {
  user: User;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user }) => {
  return (
    <div className="user-card">
      <h3>{user.name}</h3>
      <p className="email-label">Email: {user.email}</p>
      <span className="role-badge">{user.role}</span>
    </div>
  );
};
