import { User } from "../types/user";

export async function fetchUsers(): Promise<User[]> {
  const res = await fetch("/users");
  return res.json();
}

export async function fetchUserById(id: number): Promise<User> {
  const res = await fetch(`/users/${id}`);
  return res.json();
}
